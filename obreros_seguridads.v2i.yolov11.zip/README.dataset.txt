# obreros_seguridads > 2025-05-10 2:26am
https://universe.roboflow.com/ia-vision-hgnne/obreros_seguridads

Provided by a Roboflow user
License: CC BY 4.0


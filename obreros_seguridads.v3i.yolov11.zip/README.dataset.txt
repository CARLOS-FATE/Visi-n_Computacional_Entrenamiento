# obreros_seguridads > 2025-05-10 1:36pm
https://universe.roboflow.com/ia-vision-hgnne/obreros_seguridads

Provided by a Roboflow user
License: CC BY 4.0

